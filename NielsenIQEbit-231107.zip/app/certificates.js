var list = [
        {
          "image": "amazon.svg",
          "name": "Amazon",
          "value": "$200",
          "desc": "Las Tarjetas Regalo de Amazon.com.mx pueden canjearse por millones de productos de Amazon. Las Tarjetas Regalo de Amazon.com.mx pueden ser utilizados únicamente en la compra de productos participantes en <a href=\"https://www.amazon.com.mx\" target=\"_blank\">amazon.com.mx</a>."
        },
        {
          "image": "itunes.svg",
          "name": "iTunes",
          "value": "$200",
          "desc": "Disfruta de una experiencia de entretenimiento totalmente nueva. Utiliza la Tarjeta App Store & iTunes para comprar apps, juegos, música y películas. Válida únicamente para compras realizadas en México de Apple Media Services."
        },
        /*
        {
          "image": "puntosfutbol.svg",
          "name": "Puntos Futbol",
          "value": "$200",
          "desc": "Puntos Fútbol es una plataforma de entretenimiento para los fanátic@s del Fútbol, usa tu saldo para partiicpar en Trivias, Subastas, Marcadores y Retas donde podrás demostrar tus conocimientos y ganar increíbles premios."
        },
        */
        {
          "image": "spotify.svg",
          "name": "Spotify",
          "value": "$200",
          "desc": "La tarjeta de regalo es válida para planes Premium Individual. No es posible usarlas para Premium para Estudiantes, Premium Familiar, Premium Duo ni ofertas de prueba."
        },
        {
          "image": "uber.svg",
          "name": "Uber",
          "value": "$200",
          "desc": "Paga tus viajes de Uber. Esta tarjeta puede ser canjeada a través de la aplicación móvil de Uber pude ser utilizada en las ciudades en México donde Uber está disponible y en dónde no existan restricciones legales o regulatorias para su uso. La tarjeta no puede ser utilizada fuera de México."
        },
        {
          "image": "ubereats.svg",
          "name": "Uber Eats",
          "value": "$200",
          "desc": "Paga tus comidas de Uber Eats. Esta tarjeta puede ser canjeada a través de la aplicación móvil de Uber Eats pude ser utilizada en las ciudades en México donde Uber Eats está disponible y en dónde no existan restricciones legales o regulatorias para su uso. La tarjeta no puede ser utilizada fuera de México."
        }
      ]
export default {list} 